# Mukushi Secondary Staff Attendance (Android starter project)

This is a native Kotlin Android project for an offline-first attendance prototype.

## Included
- First-run creation of an administrator account.
- Staff/admin usernames and 6–12 digit PINs.
- PINs are salted and hashed with PBKDF2-HMAC-SHA256; the plain PIN is not stored.
- Local SQLite storage, so check-in/out works without internet.
- Official reporting time set to 07:10; later check-ins are labelled Late.
- Daily PDF and CSV exports (CSV can be opened by Excel).
- Local audit entries for account creation and attendance events.
- Backup is disabled in the manifest.

## Important limitation before school-wide deployment
This starter stores data on each phone only. It does **not** yet synchronize records between different teachers' phones or across administrators' phones. For a real school deployment, configure a secure backend (for example, Firebase Authentication + Firestore with role-based security rules) and an offline sync queue. Without that backend, an administrator can only see records stored on their own phone. Do not use the prototype as the official attendance register until cross-device sync, clock-tampering controls, admin authorization, and recovery/backup are implemented and tested.

Account creation in this starter is local to the phone. The first account on a fresh installation becomes an administrator. This is acceptable for a demo, not for production multi-admin provisioning.

## Build an APK
1. On a computer, install Android Studio (current stable) and its Android SDK (API 35).
2. Open this folder in Android Studio and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
5. Test first on a spare phone with sample accounts and dates.
6. For release, create a signed APK in Android Studio. Keep the signing key private.

You can also upload this project to a private Git repository and build it with a configured Android CI runner.

## Suggested production architecture
- Android client: Kotlin, SQLite/Room local queue, WorkManager sync.
- Backend: Firebase Authentication, Firestore, App Check, strict rules by school and role.
- Identity: school-issued unique staff IDs, admin invitation/provisioning, PIN retry throttling and reset process.
- Sync: immutable event IDs, server timestamps, idempotent uploads, visible pending-sync status.
- Reporting: server-side consolidated reports, PDF and XLSX/CSV exports.
- Clock integrity: server timestamps when online; flag offline timestamps for review. Device time can be changed, so offline times cannot be treated as tamper-proof.
- Privacy: restrict exports to administrators; document retention and staff notice.

## Notes
- Uses Android platform `PdfDocument`; CSV export is Excel-compatible. A true `.xlsx` workbook is not included yet.
- Reports are shared through Android's share sheet.
- Package name: `zw.mukushi.attendance`.
