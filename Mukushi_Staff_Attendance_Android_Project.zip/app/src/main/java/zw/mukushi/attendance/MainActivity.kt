package zw.mukushi.attendance

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

private const val SCHOOL = "Mukushi Secondary"
private const val REPORTING_TIME = "07:10"
private const val PREFS = "mukushi_attendance_prefs"

class MainActivity : Activity() {
    private lateinit var db: AttendanceDb
    private var signedInId: Long = -1
    private var signedInName = ""
    private var signedInRole = ""
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = AttendanceDb(this)
        showLogin()
    }

    private fun page(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 24)
            setBackgroundColor(0xFFF6F8FB.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        root.addView(TextView(this).apply {
            text = SCHOOL
            textSize = 23f
            setTextColor(0xFF174A35.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 4)
        })
        root.addView(TextView(this).apply {
            text = title
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        })
    }

    private fun addText(text: String, size: Float = 15f) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFF202124.toInt())
            setPadding(0, 8, 0, 8)
        })
    }

    private fun field(hint: String, pin: Boolean = false): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            textSize = 16f
            setSingleLine(true)
            setPadding(18, 8, 18, 8)
        }
        if (pin) e.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        root.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        return e
    }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 4; bottomMargin = 4 })
    }

    private fun showLogin() {
        page("Staff attendance")
        if (!db.hasAnyUser()) {
            addText("First-time setup: create the first administrator account. Keep the PIN private.")
            val name = field("Administrator full name")
            val username = field("Username (e.g. admin)")
            val pin = field("Create 6–12 digit PIN", true)
            val confirm = field("Confirm PIN", true)
            button("Create administrator") {
                val n = name.text.toString().trim()
                val u = username.text.toString().trim()
                val p = pin.text.toString()
                if (n.isBlank() || u.isBlank() || p.length !in 6..12 || p != confirm.text.toString()) {
                    toast("Enter a name, username, matching PINs (6–12 digits).")
                } else if (db.userExists(u)) {
                    toast("That username already exists.")
                } else {
                    db.addUser(n, u, p, "ADMIN")
                    toast("Administrator created. Please sign in.")
                    showLogin()
                }
            }
            return
        }
        addText("Sign in with your school username and PIN.")
        val username = field("Username")
        val pin = field("PIN", true)
        button("Log in") {
            val user = db.authenticate(username.text.toString().trim(), pin.text.toString())
            if (user == null) toast("Incorrect username or PIN.")
            else {
                signedInId = user.id
                signedInName = user.name
                signedInRole = user.role
                showHome()
            }
        }
        addText("Offline mode: attendance is saved on this phone.", 13f)
    }

    private fun showHome() {
        page("Welcome, $signedInName")
        addText("Today: ${today()}   •   Official reporting time: $REPORTING_TIME")
        addText("Role: $signedInRole")
        if (signedInRole == "STAFF") {
            val state = db.todayState(signedInId)
            addText(when (state) {
                "NONE" -> "You have not logged in today."
                "IN" -> "You logged in today. Please log out when leaving."
                else -> "You have completed today's log-in and log-out."
            })
            button("Log in for today") {
                if (db.todayState(signedInId) != "NONE") toast("A log-in is already recorded for today.")
                else {
                    db.checkIn(signedInId)
                    toast("Log-in recorded.")
                    showHome()
                }
            }
            button("Log out for today") {
                if (db.todayState(signedInId) != "IN") toast("You must log in before logging out.")
                else {
                    db.checkOut(signedInId)
                    toast("Log-out recorded.")
                    showHome()
                }
            }
        } else {
            button("Manage staff and administrators") { showManageUsers() }
            button("View today's attendance") { showAttendance() }
            button("Export CSV / Excel-compatible report") { exportCsv() }
            button("Export PDF report") { exportPdf() }
        }
        button("Log out of app") {
            signedInId = -1
            signedInName = ""
            signedInRole = ""
            showLogin()
        }
    }

    private fun showManageUsers() {
        page("Manage staff and administrators")
        addText("Create accounts. Staff should use their own username and PIN on their phone.")
        val name = field("Full name")
        val username = field("Username")
        val pin = field("Temporary PIN (6–12 digits)", true)
        val role = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("STAFF", "ADMIN"))
        }
        root.addView(role)
        button("Add account") {
            val n = name.text.toString().trim()
            val u = username.text.toString().trim()
            val p = pin.text.toString()
            if (n.isBlank() || u.isBlank() || p.length !in 6..12) toast("Complete all fields; PIN must be 6–12 digits.")
            else if (db.userExists(u)) toast("Username already exists.")
            else {
                db.addUser(n, u, p, role.selectedItem.toString())
                toast("Account added on this phone.")
                showManageUsers()
            }
        }
        addText("Accounts on this phone")
        db.listUsers().forEach { addText("${it.name} • ${it.username} • ${it.role}") }
        button("Back") { showHome() }
    }

    private fun showAttendance() {
        page("Today's attendance")
        val rows = db.reportRows(today())
        if (rows.isEmpty()) addText("No attendance records yet.")
        rows.forEach { r ->
            addText("${r.name}\nLog in: ${r.inTime ?: "—"}   Log out: ${r.outTime ?: "—"}   Status: ${r.status}")
        }
        button("Export today's CSV") { exportCsv(today()) }
        button("Export today's PDF") { exportPdf(today()) }
        button("Back") { showHome() }
    }

    private fun exportCsv(date: String? = null) {
        val rows = db.reportRows(date)
        val csv = buildString {
            appendLine("School,Date,Staff,Log in,Log out,Status")
            rows.forEach { r ->
                appendLine(listOf(SCHOOL, r.date, r.name, r.inTime ?: "", r.outTime ?: "", r.status)
                    .joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
            }
        }
        try {
            val f = File(getExternalFilesDir(null), "Mukushi_Attendance_${date ?: today()}.csv")
            f.writeText(csv)
            shareFile(f, "text/csv", "CSV report created. Share it to save or open in Excel.")
        } catch (e: Exception) { toast("Could not export CSV: ${e.message}") }
    }

    private fun exportPdf(date: String? = null) {
        val rows = db.reportRows(date)
        val doc = PdfDocument()
        val paint = Paint().apply { textSize = 11f }
        val titlePaint = Paint().apply { textSize = 17f; isFakeBoldText = true }
        var pageNo = 1
        var p = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        var canvas = p.canvas
        var y = 45f
        canvas.drawText(SCHOOL, 40f, y, titlePaint); y += 24
        canvas.drawText("Staff attendance report • ${date ?: "All available dates"}", 40f, y, paint); y += 20
        canvas.drawText("Official reporting time: $REPORTING_TIME", 40f, y, paint); y += 24
        rows.forEach { r ->
            if (y > 790) {
                doc.finishPage(p); pageNo++
                p = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
                canvas = p.canvas; y = 45f
            }
            canvas.drawText("${r.date} | ${r.name}", 40f, y, paint); y += 15
            canvas.drawText("In: ${r.inTime ?: "—"}   Out: ${r.outTime ?: "—"}   Status: ${r.status}", 55f, y, paint); y += 20
        }
        doc.finishPage(p)
        try {
            val f = File(getExternalFilesDir(null), "Mukushi_Attendance_${date ?: today()}.pdf")
            FileOutputStream(f).use { doc.writeTo(it) }
            doc.close()
            shareFile(f, "application/pdf", "PDF report created. Share it to save or print.")
        } catch (e: Exception) { doc.close(); toast("Could not export PDF: ${e.message}") }
    }

    private fun shareFile(file: File, mime: String, message: String) {
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = mime
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        // FileProvider is configured below; chooser makes export accessible to the user.
        startActivity(android.content.Intent.createChooser(intent, "Share attendance report"))
        toast(message)
    }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun now() = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    data class User(val id: Long, val name: String, val username: String, val role: String)
    data class Row(val date: String, val name: String, val inTime: String?, val outTime: String?, val status: String)

    inner class AttendanceDb(ctx: Context) : SQLiteOpenHelper(ctx, "mukushi_attendance.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, username TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, pin_hash TEXT NOT NULL, role TEXT NOT NULL)")
            db.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, date TEXT NOT NULL, in_time TEXT, out_time TEXT, UNIQUE(user_id,date), FOREIGN KEY(user_id) REFERENCES users(id))")
            db.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER, action TEXT, at TEXT)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
        fun hasAnyUser() = readableDatabase.rawQuery("SELECT COUNT(*) FROM users", null).use { it.moveToFirst(); it.getInt(0) > 0 }
        fun userExists(u: String) = readableDatabase.rawQuery("SELECT COUNT(*) FROM users WHERE username=?", arrayOf(u)).use { it.moveToFirst(); it.getInt(0) > 0 }
        fun addUser(name: String, username: String, pin: String, role: String) {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val values = ContentValues().apply {
                put("name", name); put("username", username); put("salt", salt.joinToString("") { b -> "%02x".format(b) })
                put("pin_hash", hashPin(pin, salt)); put("role", role)
            }
            writableDatabase.insertOrThrow("users", null, values)
            audit(-1, "ACCOUNT_CREATED:$username:$role")
        }
        fun authenticate(username: String, pin: String): User? {
            readableDatabase.rawQuery("SELECT id,name,username,salt,pin_hash,role FROM users WHERE username=?", arrayOf(username)).use {
                if (!it.moveToFirst()) return null
                val salt = hexToBytes(it.getString(3))
                if (hashPin(pin, salt) != it.getString(4)) return null
                return User(it.getLong(0), it.getString(1), it.getString(2), it.getString(5))
            }
        }
        fun listUsers(): List<User> {
            val out = mutableListOf<User>()
            readableDatabase.rawQuery("SELECT id,name,username,role FROM users ORDER BY name", null).use {
                while (it.moveToNext()) out.add(User(it.getLong(0), it.getString(1), it.getString(2), it.getString(3)))
            }
            return out
        }
        fun todayState(uid: Long): String {
            readableDatabase.rawQuery("SELECT in_time,out_time FROM attendance WHERE user_id=? AND date=?", arrayOf(uid.toString(), today())).use {
                if (!it.moveToFirst()) return "NONE"
                return if (it.isNull(0)) "NONE" else if (it.isNull(1)) "IN" else "DONE"
            }
        }
        fun checkIn(uid: Long) {
            val v = ContentValues().apply { put("user_id", uid); put("date", today()); put("in_time", now()) }
            writableDatabase.insertOrThrow("attendance", null, v)
            audit(uid, "CHECK_IN")
        }
        fun checkOut(uid: Long) {
            val v = ContentValues().apply { put("out_time", now()) }
            writableDatabase.update("attendance", v, "user_id=? AND date=? AND out_time IS NULL", arrayOf(uid.toString(), today()))
            audit(uid, "CHECK_OUT")
        }
        fun reportRows(date: String? = null): List<Row> {
            val rows = mutableListOf<Row>()
            val sql = "SELECT a.date,u.name,a.in_time,a.out_time FROM attendance a JOIN users u ON u.id=a.user_id" +
                    if (date != null) " WHERE a.date=? ORDER BY u.name" else " ORDER BY a.date DESC,u.name"
            readableDatabase.rawQuery(sql, if (date != null) arrayOf(date) else null).use {
                while (it.moveToNext()) {
                    val d = it.getString(0); val inn = it.getString(2); val out = it.getString(3)
                    val status = when {
                        inn == null -> "Absent/No log-in"
                        inn > "$REPORTING_TIME:00" -> "Late"
                        out == null -> "Logged in"
                        else -> "Complete"
                    }
                    rows.add(Row(d, it.getString(1), inn, out, status))
                }
            }
            return rows
        }
        private fun audit(actor: Long, action: String) {
            val v = ContentValues().apply { put("actor_id", actor); put("action", action); put("at", "${today()} ${now()}") }
            writableDatabase.insert("audit", null, v)
        }
    }

    private fun hashPin(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return bytes.joinToString("") { "%02x".format(it) }
    }
    private fun hexToBytes(s: String) = s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
