plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "zw.mukushi.attendance"
    compileSdk = 35
    defaultConfig {
        applicationId = "zw.mukushi.attendance"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}

dependencies { implementation("androidx.core:core:1.15.0") }
